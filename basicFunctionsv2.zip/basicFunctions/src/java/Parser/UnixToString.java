/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Parser;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 *
 * @author Lenovo
 */
public class UnixToString {

    public UnixToString() {
    }
    
    public String getTime( double unixSeconds ) {
      
        Date date = new Date((long) (unixSeconds * 1000L)); // *1000 is to convert seconds to milliseconds
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // the format of your date
        String formattedDate = sdf.format(date);
       
        
        return formattedDate;
    }
}
