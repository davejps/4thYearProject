/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Command;

import Parser.loadData;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Lenovo
 */
class importCSV implements Command {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        String forwardToJsp = null;
       boolean check;
        String filePath = request.getParameter("filePath");
        if (filePath != null) { 
            
            loadData l = new loadData();

            check = l.loadDataFromFile(filePath);
           
            if (check == true) {

                forwardToJsp = "/importSuccessful.jsp";

                HttpSession session = request.getSession();

                String confirmSession = "Session was Successfully added to the database";
                        // Need to get the session so we can use it.

                // Put this id variable into the session and label it "clientLoggedInId"
                session.setAttribute("sessionAddedConf", confirmSession);
            } else {
                forwardToJsp = "/importFailed.jsp";
            }
        }else{
            forwardToJsp = "/error.jsp";
        }
        return forwardToJsp;
    }

}
