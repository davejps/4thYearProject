/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Command;

/**
 *
 * @author Samsung
 */
public class commandFactory {

    public Command createCommand(String commandStr) {
        Command command = null;

        if (commandStr.equals("importCSV")) {
            command = new importCSV();
        }
        if (commandStr.equals("viewAllSessionsHeatmap")) {
            command = new getSessionsHeatmap();
        }
        if (commandStr.equals("viewHeatmapAll")) {
            command = new viewAllPoints();
        }
        if (commandStr.equals("viewHeatmapPerMin")) {
            command = new viewPointPerMin();
        }
        if (commandStr.equals("viewAllSessionCalcs")) {
            command = new getSessionCalcs();
        }
        if (commandStr.equals("viewCalcTotals")) {
            command = new getCalcTotals();
        }
        //Return the instantiated Command object to the calling code...
        return command;// may be null
    }
}
