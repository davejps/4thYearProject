/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Command;

import DAO.GPSDao;
import DAO.SessionDao;
import DTO.GPS;
import DTO.Session;
import Exceptions.DaoException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Lenovo
 */
class viewAllPoints implements Command {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        String forwardToJsp = null;

        String commandAction = request.getParameter("action");
        if (commandAction != null) {
            if (commandAction.equals("viewHeatmapAll")) {

                HttpSession session = request.getSession();

                int sessionId = Integer.parseInt(request.getParameter("sessionIdentifier"));
                GPSDao g = new GPSDao();
                SessionDao s1 = new SessionDao();
                try {

                    Session s = s1.getSessionById(sessionId);
                    List<GPS> g1 = g.getAllRecordsBySessionId(sessionId);
                    session.setAttribute("records", g1);
                    session.setAttribute("session", s);
                    //To change body of generated methods, choose Tools | Templates.
                } catch (DaoException ex) {
                    Logger.getLogger(getSessionsHeatmap.class.getName()).log(Level.SEVERE, null, ex);

                    // Put the list of artists into the session
                }

                forwardToJsp = "/canvasAllPoints.jsp";
            }

        }
        return forwardToJsp;
    }

}
