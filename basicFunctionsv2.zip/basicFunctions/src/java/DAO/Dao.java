/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Exceptions.DaoException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author Lenovo
 */
public class Dao {

    
      public Connection getConnection() throws DaoException{
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/statssportsdata"; 
        String username = "root";
        String password = "";
        Connection con = null;
        
        try{
            Class.forName(driver);
            con = DriverManager.getConnection(url , username , password);
        } catch(SQLException e){
            throw new DaoException("getConnection: " + e.getMessage());
        } catch(ClassNotFoundException c){
            throw new DaoException("getConnection: " + c.getMessage());
        }
        return con;
    }
    
    public void freeConnection(Connection con) throws DaoException{
        try{
            if(con!=null){
                con.close();
                con =null;
            }
        } catch(SQLException s){
            throw new DaoException("freeConnection: " + s.getMessage());
        }
    }
}
