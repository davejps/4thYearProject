/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

import java.util.Date;
import java.sql.Time;
import java.util.Objects;

/**
 *
 * @author Lenovo
 */
public class Session {

    private int sessionId;
    private Date sessionDate;
    private Time startTime;
    private Time endTime;
    private double bottomLeftLat;
    private double bottomLeftLong;
    private double bottomRightLat;
    private double bottomRightLong;
    private double topLeftLat;
    private double topLeftLong;

    public Session() {
    }

    public Session(int sessionId, Date sessionDate, Time startTime, Time endTime, double bottomLeftLat, double bottomLeftLong, double bottomRightLat, double bottomRightLong, double topLeftLat, double topLeftLong) {
        this.sessionId = sessionId;
        this.sessionDate = sessionDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.bottomLeftLat = bottomLeftLat;
        this.bottomLeftLong = bottomLeftLong;
        this.bottomRightLat = bottomRightLat;
        this.bottomRightLong = bottomRightLong;
        this.topLeftLat = topLeftLat;
        this.topLeftLong = topLeftLong;
    }

    public Session(Date sessionDate, Time startTime, Time endTime, double bottomLeftLat, double bottomLeftLong, double bottomRightLat, double bottomRightLong, double topLeftLat, double topLeftLong) {

        this.sessionDate = sessionDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.bottomLeftLat = bottomLeftLat;
        this.bottomLeftLong = bottomLeftLong;
        this.bottomRightLat = bottomRightLat;
        this.bottomRightLong = bottomRightLong;
        this.topLeftLat = topLeftLat;
        this.topLeftLong = topLeftLong;
    }

    public Session(int sessionId, Date sessionDate, Time startTime) {
        this.sessionId = sessionId;
        this.sessionDate = sessionDate;
        this.startTime = startTime;
    }

    public Date getSessionDate() {
        return sessionDate;
    }

    public int getSessionId() {
        return sessionId;
    }

    public void setSessionId(int sessionId) {
        this.sessionId = sessionId;
    }

    public Time getStartTime() {
        return startTime;
    }

    public void setStartTime(Time startTime) {
        this.startTime = startTime;
    }

    public Time getEndTime() {
        return endTime;
    }

    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }

    public double getBottomLeftLat() {
        return bottomLeftLat;
    }

    public void setBottomLeftLat(double bottomLeftLat) {
        this.bottomLeftLat = bottomLeftLat;
    }

    public double getBottomLeftLong() {
        return bottomLeftLong;
    }

    public void setBottomLeftLong(double bottomLeftLong) {
        this.bottomLeftLong = bottomLeftLong;
    }

    public double getBottomRightLat() {
        return bottomRightLat;
    }

    public void setBottomRightLat(double bottomRightLat) {
        this.bottomRightLat = bottomRightLat;
    }

    public double getBottomRightLong() {
        return bottomRightLong;
    }

    public void setBottomRightLong(double bottomRightLong) {
        this.bottomRightLong = bottomRightLong;
    }

    public double getTopLeftLat() {
        return topLeftLat;
    }

    public void setTopLeftLat(double topLeftLat) {
        this.topLeftLat = topLeftLat;
    }

    public double getTopLeftLong() {
        return topLeftLong;
    }

    public void setTopLeftLong(double topLeftLong) {
        this.topLeftLong = topLeftLong;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Session other = (Session) obj;
        if (!Objects.equals(this.sessionId, other.sessionId)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Session{" + "sessionId=" + sessionId + ", startTime=" + startTime + ", endTime=" + endTime + ", bottomLeftLat=" + bottomLeftLat + ", bottomLeftLong=" + bottomLeftLong + ", bottomRightLat=" + bottomRightLat + ", bottomRightLong=" + bottomRightLong + ", topLeftLat=" + topLeftLat + ", topLeftLong=" + topLeftLong + '}';
    }

}
