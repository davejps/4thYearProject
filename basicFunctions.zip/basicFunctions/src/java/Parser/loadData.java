/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Parser;

import DAO.SessionDao;
import DTO.GPS;
import DTO.GPSData;
import DTO.Session;
import Exceptions.DaoException;
import GPScalculation.findAngle;
import GPScalculation.findCoords;
import GPScalculation.haversineFormula;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class loadData {

    public boolean loadDataFromFile(String filepath) {

        SessionDao sD = new SessionDao();
        UnixToString un = new UnixToString();
        timeParser tp = new timeParser();
        dateParser dp = new dateParser();
        haversineFormula h1 = new haversineFormula();
        findCoords f1 = new findCoords();
        findAngle a1 = new findAngle();
        GPSData g = new GPSData();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/statssportsdata", "root", "");
            Scanner scanner = new Scanner(new FileReader(filepath));

            PreparedStatement ps;
            ResultSet rs;
            Statement s = con.createStatement();
            String q = "SET autocommit = 0";
            s.executeQuery(q);

            // get the line
            scanner.nextLine();
            scanner.nextLine();
            scanner.nextLine();
            scanner.nextLine();
            String[] timeDate = scanner.nextLine().split(",");
            double startTime = Double.parseDouble(timeDate[1]);
            double endTime = Double.parseDouble(timeDate[2]);
            String sTimeString = un.getTime(startTime);
            String eTimeString = un.getTime(endTime);
            //System.out.println(sTimeString+" "+eTimeString);
            Date d = dp.parseDate(sTimeString);
            Time start = tp.parseTime(sTimeString);
            Time end = tp.parseTime(eTimeString);
            scanner.nextLine();
            String[] corners = scanner.nextLine().split(",");
            double btmLeftLat = Double.parseDouble(corners[0]);
            double btmLeftLong = Double.parseDouble(corners[1]);
            double btmRightLat = Double.parseDouble(corners[2]);
            double btmRightLong = Double.parseDouble(corners[3]);
            double topLeftLat = Double.parseDouble(corners[4]);
            double topLeftLong = Double.parseDouble(corners[5]);
            Session s1 = new Session(d, start, end, btmLeftLat, btmLeftLong, btmRightLat, btmRightLong, topLeftLat, topLeftLong);
            if (sD.checktoSeeIfRecordIn(s1) == true) {
                System.out.println("Sorry this record has already been added");
                //return false;
            } else {
                System.out.println(sD.addRecord(s1));

                double degreeError = a1.getAngle(btmLeftLat, btmLeftLong, btmRightLat, btmRightLong);
                double angleAllPitch = a1.getAngle(btmLeftLat, btmLeftLong, topLeftLat, topLeftLong) - degreeError;
                double factorToNormalise = (90 / angleAllPitch);
            // System.out.println("Factor to Normalise: " + factorToNormalise);
                // System.out.println("Degree Error: " +degreeError);
                scanner.nextLine();
                String line = null;
                double GPSTime;
                double latitude;
                double longitude;
                double speed;
                double hypotenuse;
                double angleToPoint;
                String cTimeString;
                Time current;
                double normalisedDegree;
                double x;
                double y;
                GPS gp = null;
                while (scanner.hasNextLine()) {
                    line = scanner.nextLine();
                    String[] results = line.split(",");
                    //System.out.println(Arrays.toString(results));

                    if (!results[0].isEmpty() || !results[1].isEmpty() || !results[2].isEmpty() || !results[3].isEmpty()) {
                        GPSTime = Double.parseDouble(results[0]);
                        cTimeString = un.getTime(GPSTime);
                        current = tp.parseCurrentTime(cTimeString, start);
                        //System.out.println(current);

                        latitude = Double.parseDouble(results[1]);
                        longitude = Double.parseDouble(results[2]);
                        hypotenuse = h1.haversine(btmLeftLat, btmLeftLong, latitude, longitude);
                        //System.out.println(hypotenuse + " metres");
                        angleToPoint = a1.getAngle(btmLeftLat, btmLeftLong, latitude, longitude) - degreeError;
                        normalisedDegree = angleToPoint * factorToNormalise;

                        x = f1.findX(normalisedDegree, hypotenuse);
                        y = f1.findY(normalisedDegree, hypotenuse);

                        // System.out.println(x+" "+y);
                        speed = Double.parseDouble(results[3]);
                        gp = new GPS(current, x, y, speed, d);
                        g.addToArray(gp);
                    }

                }
                int counter = 0;
                for (GPS gps : g.getGpsData()) {
                    String query = "INSERT INTO `gps`(`GPSTime`, `latitude`, `longitude`, `speed`, `sessionId`) VALUES (? , ? , ? , ? , ?)";
                    ps = con.prepareStatement(query);
                    ps.setTime(1, gps.getTime());
                    ps.setDouble(2, gps.getLatitude());
                    ps.setDouble(3, gps.getLongitude());
                    ps.setDouble(4, gps.getSpeed());
                    java.sql.Date sessionDate = new java.sql.Date(d.getTime());
                    ps.setDate(5, sessionDate);

                    ps.executeUpdate();

                    counter++;

                    if (counter == 999) {
                        String p = "COMMIT";
                        s.executeQuery(p);
                        counter = 0;
                    }
                }
                String p = "COMMIT";
                s.executeQuery(p);
                return true;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(loadData.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(loadData.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(loadData.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(loadData.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(loadData.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NullPointerException ex) {
            Logger.getLogger(loadData.class.getName()).log(Level.SEVERE, null, ex);
            ex.getMessage();
        }
        return false;
    }

    public static void main(String[] args) {
        loadData l = new loadData();
        System.out.println(l.loadDataFromFile("C:\\Users\\Lenovo\\Desktop\\John_14 Nov 2015.csv"));
    }

}
