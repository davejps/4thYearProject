/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Parser;

import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class timeParser {

    public Time parseTime(String startDateString) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date startDate;
        Time t = null;
        try {
            startDate = df.parse(startDateString);
            int hour = startDate.getHours();
            int minutes = startDate.getMinutes();
            int seconds = startDate.getSeconds();
            t = new Time(hour, minutes, seconds);

        } catch (ParseException ex) {
            Logger.getLogger(timeParser.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NullPointerException e) {
            Logger.getLogger(timeParser.class.getName()).log(Level.SEVERE, null, e);
            e.getMessage();
        }
        return t;
    }

    public Time parseCurrentTime(String currentDateString, Time st) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date currentTime;
        Time t = null;
        try {
            currentTime = df.parse(currentDateString);

            int hour = currentTime.getHours() - st.getHours();
            int minutes = currentTime.getMinutes() - st.getMinutes();
            int seconds = currentTime.getSeconds() - st.getSeconds();
            t = new Time(hour, minutes, seconds);

        } catch (ParseException ex) {
            Logger.getLogger(timeParser.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NullPointerException e) {
            Logger.getLogger(timeParser.class.getName()).log(Level.SEVERE, null, e);
            e.getMessage();
        }
        return t;
    }

    public static void main(String[] args) {
        timeParser tp = new timeParser();
        UnixToString un = new UnixToString();
        Time t = new Time(13, 52, 19);
        double unix = 1447511712;
        String startDateString = un.getTime(unix);
        System.out.println("Current time is: " +tp.parseCurrentTime(startDateString,t));
    }
}
