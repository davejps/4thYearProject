/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Command;

import DAO.GPSDao;
import DAO.SessionDao;
import DTO.GPS;
import DTO.Session;
import Exceptions.DaoException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Lenovo
 */
class viewAllPoints implements Command {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        String forwardToJsp = null;
        

        String commandAction = request.getParameter("action");
        if (commandAction != null) {
            if (commandAction.equals("viewHeatmapAll")) {

                SessionDao s1 = new SessionDao();
                HttpSession session = request.getSession();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                String dateStr = request.getParameter("sessionIdentifier");
                Date d ;
                GPSDao g = new GPSDao();
                Session s = null;
                Date sessionDate = null;
                List<GPS> g1 = new ArrayList<GPS>();
                try {
                    d = formatter.parse(dateStr);
                    int year = d.getYear();
                    int month = d.getMonth();
                    int day = d.getDate();
                    sessionDate = new Date(year, month, day);
                    g1 = g.getAllRecordsBySessionId(sessionDate);
                    s = s1.getSessionById(sessionDate);//To change body of generated methods, choose Tools | Templates.
                } catch (DaoException ex) {
                    Logger.getLogger(getSessionsHeatmap.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ParseException ex) {
                    Logger.getLogger(viewAllPoints.class.getName()).log(Level.SEVERE, null, ex);
                }
                // Put the list of artists into the session
                session.setAttribute("records", g1);
                session.setAttribute("session", s);
                forwardToJsp = "/canvasAllPoints.jsp";
            }

        }
        return forwardToJsp;
    }

}
