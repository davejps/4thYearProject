/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;


import java.util.Date;
import java.sql.Time;


/**
 *
 * @author Lenovo
 */
public class GPS {

    private Time time;
    private double latitude;
    private double longitude;
    private double speed;
    private Date sessionId;
    
    public GPS() {
    }

    public GPS(Time time, double latitude, double longitude, double speed) {
        this.time = time;
        this.latitude = latitude;
        this.longitude = longitude;
        this.speed = speed;
    }

    public GPS(Time time, double latitude, double longitude, double speed, Date sessionId) {
        this.time = time;
        this.latitude = latitude;
        this.longitude = longitude;
        this.speed = speed;
        this.sessionId = sessionId;
    }
    
    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public Date getSessionId() {
        return sessionId;
    }

    public void setSessionId(Date sessionId) {
        this.sessionId = sessionId;
    }

    @Override
    public String toString() {
        return "GPS{" + "time=" + time + ", latitude=" + latitude + ", longitude=" + longitude + ", speed=" + speed + ", sessionId=" + sessionId + '}';
    }

  
    
}
