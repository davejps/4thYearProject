/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

import java.sql.Time;
import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class GPSData {

    private ArrayList<GPS> gpsData;

    public GPSData() {
        gpsData = new ArrayList<GPS>();
    }

    public int arraySize() {
        return gpsData.size();
    }

    public ArrayList<GPS> getGpsData() {
        return gpsData;
    }

    @Override
    public String toString() {
        return "GPSData{" + "gpsData=" + gpsData + '}';
    }

    public void addToArray(GPS r) {
        if (r.getTime().getSeconds()!= 0) {
            Time GPSTime = r.getTime();
            double latitude = r.getLatitude();
            double longitude = r.getLongitude();
            double speed = r.getSpeed();

            GPS g = new GPS(GPSTime, latitude, longitude, speed);
            gpsData.add(g);
        }

    }
    
    public double findMaxSpeed(){
        double speed=gpsData.get(0).getSpeed();
       for(GPS g: gpsData){
           if(speed<g.getSpeed()){
               speed= g.getSpeed();
           }
       }
       return speed;
    }
      public double findAvgSpeed(){
        double speed=0;
       for(GPS g: gpsData){
           
               speed += g.getSpeed();
           
       }
       speed = speed/gpsData.size();
       return speed;
    }
    
      
     
}
