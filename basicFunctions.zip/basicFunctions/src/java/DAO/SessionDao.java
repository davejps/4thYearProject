/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.Session;
import Exceptions.DaoException;
import Parser.UnixToString;
import Parser.dateParser;
import Parser.timeParser;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class SessionDao extends Dao {

    public int addRecord(Session s1) throws DaoException, ParseException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = null;
        int rowsAffected = 0;

        try {
            //Get connection object using the methods in the super class (Dao.java)...
            con = this.getConnection();

            String query = "INSERT INTO `sessions`(`sessionId`, `startTime`, `endTime`, `bottomLeftLat`, `bottomLeftLong`, `bottomRightLat`, `bottomRightLong`, `topLeftLat`, `topLeftLong`) VALUES (?,?,?,?,?,?,?,?,?)";
            ps = con.prepareStatement(query);
            java.sql.Date sessionDate = new java.sql.Date(s1.getSessionId().getTime());
            ps.setDate(1, sessionDate);
            ps.setTime(2, s1.getStartTime());
            ps.setTime(3, s1.getEndTime());
            ps.setDouble(4, s1.getBottomLeftLat());
            ps.setDouble(5, s1.getBottomLeftLong());
            ps.setDouble(6, s1.getBottomRightLat());
            ps.setDouble(7, s1.getBottomRightLong());
            ps.setDouble(8, s1.getTopLeftLat());
            ps.setDouble(9, s1.getTopLeftLong());
            ps.executeUpdate();
            rowsAffected = rowsAffected + 1;

        } catch (SQLException e) {
            throw new DaoException("addSession: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException("addSession: " + e.getMessage());
            }
        }
        return rowsAffected;

    }

    public boolean checktoSeeIfRecordIn(Session s1) throws DaoException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = null;
        int rowsAffected = 0;
        try {
            con = this.getConnection();

            String query = "SELECT * FROM sessions WHERE sessionId =(?)";
            ps = con.prepareStatement(query);
            java.sql.Date sessionDate = new java.sql.Date(s1.getSessionId().getTime());
            ps.setDate(1, sessionDate);
            rs = ps.executeQuery();
            while (rs.next()) {
                Date found = rs.getDate("sessionId");

                if ((sessionDate.getDate() == found.getDate()) && (sessionDate.getMonth() == found.getMonth())) {
                    return true;
                }
            }
        } catch (SQLException e) {
            throw new DaoException("checktoSeeIfRecordIn() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException(e.getMessage());
            }
        }
        return false;
    }

    public Session getSessionById(Date sessionId) throws DaoException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = null;
        Session s = null;
        try {
            con = this.getConnection();

            String query = "SELECT * FROM sessions WHERE sessionId =(?)";
            ps = con.prepareStatement(query);
            java.sql.Date sessionDate = new java.sql.Date(sessionId.getTime());
            ps.setDate(1, sessionDate);
            rs = ps.executeQuery();
            while (rs.next()) {
                Date date = rs.getDate("sessionId");
                Time start = rs.getTime("startTime");
                Time end = rs.getTime("endTime");
                double bottomLeftLat = rs.getDouble("bottomLeftLat");
                double bottomLeftLong = rs.getDouble("bottomLeftLong");
                double bottomRightLat = rs.getDouble("bottomRightLat");
                double bottomRightLong = rs.getDouble("bottomRightLong");
                double topLeftLat = rs.getDouble("topLeftLat");
                double topLeftLong = rs.getDouble("topLeftLong");
                s = new Session(date, start, end, bottomLeftLat, bottomLeftLong, bottomRightLat, bottomRightLong, topLeftLat, topLeftLong);
            }
        } catch (SQLException e) {
            throw new DaoException("checktoSeeIfRecordIn() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException(e.getMessage());
            }
        }
        return s;
    }

    public List<Session>  getAllSessions() throws DaoException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = null;
        List<Session> s1 = new ArrayList<>();
        try {
            con = this.getConnection();

            String query = "SELECT * FROM sessions";
            ps = con.prepareStatement(query);

            rs = ps.executeQuery();
            while (rs.next()) {
                Date date = rs.getDate("sessionId");
                Time start = rs.getTime("startTime");
                Time end = rs.getTime("endTime");
                double bottomLeftLat = rs.getDouble("bottomLeftLat");
                double bottomLeftLong = rs.getDouble("bottomLeftLong");
                double bottomRightLat = rs.getDouble("bottomRightLat");
                double bottomRightLong = rs.getDouble("bottomRightLong");
                double topLeftLat = rs.getDouble("topLeftLat");
                double topLeftLong = rs.getDouble("topLeftLong");
               Session s = new Session(date, start, end, bottomLeftLat, bottomLeftLong, bottomRightLat, bottomRightLong, topLeftLat, topLeftLong);
               s1.add(s);
            }
        } catch (SQLException e) {
            throw new DaoException("checktoSeeIfRecordIn() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException(e.getMessage());
            }
        }
        return s1;
    }

    public static void main(String[] args) {
        SessionDao s = new SessionDao();
        UnixToString un = new UnixToString();
        timeParser tp = new timeParser();
        dateParser dp = new dateParser();

        double unixStartTime = 1447509139;
        double unixEndTime = 1447514378;

        String startDateString = un.getTime(unixStartTime);
        String endString = un.getTime(unixEndTime);
        // System.out.println(startDateString);
        Date d = dp.parseDate(startDateString);
//        Time start = tp.parseTime(startDateString);
//        Time end = tp.parseTime(endString);
//
//        Session s1 = new Session(d, start, end);
        try {
//            if (s.checktoSeeIfRecordIn(s1) == true) {
//                System.out.println("Sorry this record has already been added");
//            } else {
//                System.out.println(s.addRecord(s1));
//            }
            List<Session> s1 = s.getAllSessions();
            System.out.println(s1.toString());
        } catch (DaoException ex) {
            Logger.getLogger(GPSDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
