/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DTO.GPS;
import Exceptions.DaoException;
import Parser.UnixToString;
import Parser.dateParser;
import Parser.timeParser;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class GPSDao extends Dao {

    public int addRecord(GPS g1) throws DaoException, ParseException {

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = null;
        int rowsAffected = 0;

        try {
            //Get connection object using the methods in the super class (Dao.java)...
            con = this.getConnection();

            String query = "INSERT INTO `gps`(`GPSTime`, `latitude`, `longitude`, `speed`, `sessionId`) VALUES (? , ? , ? , ? , ?)";
            ps = con.prepareStatement(query);

            ps.setTime(1, g1.getTime());
            ps.setDouble(2, g1.getLatitude());
            ps.setDouble(3, g1.getLongitude());
            ps.setDouble(4, g1.getSpeed());

            java.sql.Date sessionDate = new java.sql.Date(g1.getSessionId().getTime());
            ps.setDate(5, sessionDate);
            ps.executeUpdate();
            rowsAffected = rowsAffected + 1;

        } catch (SQLException e) {
            throw new DaoException("addRecord: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException("addOrder: " + e.getMessage());
            }
        }
        return rowsAffected;

    }

    public List<GPS> getAllRecords() throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<GPS> gps = new ArrayList<>();

        try {
            //Get connection object using the methods in the super class (Dao.java)...
            con = this.getConnection();

            String query = "SELECT * FROM gps";
            ps = con.prepareStatement(query);

            //Using a PreparedStatement to execute SQL...
            rs = ps.executeQuery();
            while (rs.next()) {
                Time t = rs.getTime("GPSTime");
                Double latitude = rs.getDouble("latitude");
                Double longitude = rs.getDouble("longitude");
                Double speed = rs.getDouble("speed");
                Date sessionDate = rs.getDate("sessionId");

                GPS b = new GPS(t, latitude, longitude, speed, sessionDate);
                gps.add(b);
            }
        } catch (SQLException e) {
            throw new DaoException("getAllRecords() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException(e.getMessage());
            }
        }
        return gps;     // may be empty
    }

    public List<GPS> getAllRecordsBySessionId(Date sessionId) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<GPS> gps = new ArrayList<>();

        try {
            //Get connection object using the methods in the super class (Dao.java)...
            con = this.getConnection();
            String query = "SELECT * FROM gps WHERE sessionId =(?)";
            ps = con.prepareStatement(query);
            java.sql.Date sessionDate = new java.sql.Date(sessionId.getTime());
            ps.setDate(1, sessionDate);
            rs = ps.executeQuery();
            while (rs.next()) {
                Time t = rs.getTime("GPSTime");
                Double latitude = rs.getDouble("latitude");
                Double longitude = rs.getDouble("longitude");
                Double speed = rs.getDouble("speed");
                Date date = rs.getDate("sessionId");

                GPS b = new GPS(t, latitude, longitude, speed, date);
                gps.add(b);
            }

        } catch (SQLException e) {
            throw new DaoException("getAllRecords() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException(e.getMessage());
            }
        }
        return gps;     // may be empty
    }

    public List<GPS> getAvgRecordMin(Date sessionId) throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<GPS> gps = new ArrayList<>();

        try {
            //Get connection object using the methods in the super class (Dao.java)...
            con = this.getConnection();

            String query = "SELECT `GPSTime`,AVG(`latitude`) AS latitude,AVG(`longitude`) AS longitude,AVG(`speed`) AS speed,`sessionId` FROM `gps` WHERE sessionId =(?) GROUP BY HOUR(GPSTime),MINUTE(`GPSTime`)";
           ps = con.prepareStatement(query);
            java.sql.Date sessionDate = new java.sql.Date(sessionId.getTime());
            ps.setDate(1, sessionDate);
            rs = ps.executeQuery();
            while (rs.next()) {
                Time t = rs.getTime("GPSTime");
                Double latitude = rs.getDouble("latitude");
                Double longitude = rs.getDouble("longitude");
                Double speed = rs.getDouble("speed");
                Date sessionOccured = rs.getDate("sessionId");

                GPS b = new GPS(t, latitude, longitude, speed, sessionOccured);
                gps.add(b);
            }
        } catch (SQLException e) {
            throw new DaoException("getAllRecords() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException(e.getMessage());
            }
        }
        return gps;     // may be empty
    }

    public double getAvgSpeed() throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        double avg = 0;

        try {
            //Get connection object using the methods in the super class (Dao.java)...
            con = this.getConnection();

            String query = "SELECT AVG(`speed`) AS speed FROM `gps`";
            ps = con.prepareStatement(query);

            //Using a PreparedStatement to execute SQL...
            rs = ps.executeQuery();
            while (rs.next()) {

                avg = rs.getDouble("speed");

            }
        } catch (SQLException e) {
            throw new DaoException("getAllRecords() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException(e.getMessage());
            }
        }
        return avg;     // may be empty
    }

    public double getMinSpeed() throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        double min = 0;

        try {
            //Get connection object using the methods in the super class (Dao.java)...
            con = this.getConnection();

            String query = "SELECT MIN(`speed`) AS speed FROM `gps`";
            ps = con.prepareStatement(query);

            //Using a PreparedStatement to execute SQL...
            rs = ps.executeQuery();
            while (rs.next()) {

                min = rs.getDouble("speed");

            }
        } catch (SQLException e) {
            throw new DaoException("getAllRecords() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException(e.getMessage());
            }
        }
        return min;     // may be empty
    }

    public double getMaxSpeed() throws DaoException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        double max = 0;

        try {
            //Get connection object using the methods in the super class (Dao.java)...
            con = this.getConnection();

            String query = "SELECT MAX(`speed`) AS speed FROM `gps`";
            ps = con.prepareStatement(query);

            //Using a PreparedStatement to execute SQL...
            rs = ps.executeQuery();
            while (rs.next()) {

                max = rs.getDouble("speed");

            }
        } catch (SQLException e) {
            throw new DaoException("getAllRecords() " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    freeConnection(con);
                }
            } catch (SQLException e) {
                throw new DaoException(e.getMessage());
            }
        }
        return max;     // may be empty
    }

    public static void main(String[] args) {
        GPSDao g = new GPSDao();
        UnixToString un = new UnixToString();
        timeParser tp = new timeParser();
        dateParser dp = new dateParser();

        double unixTime = 1447509139;

        String startDateString = un.getTime(unixTime);

       // System.out.println(startDateString);
       
        Time t = tp.parseTime(startDateString);
        Date d = dp.parseDate(startDateString);
//        
//        GPS g1 = new GPS(t, 24.50, 123.40, 2.34567, d);
        try {
            //System.out.println(g.addRecord(g1));
//          List<GPS>gps=  g.getAvgRecordMin();
//            for(GPS g1:gps){
//                System.out.println(g1.toString());
//            }
            System.out.println(g.getAllRecordsBySessionId(d));

        } catch (DaoException ex) {
            Logger.getLogger(GPSDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
